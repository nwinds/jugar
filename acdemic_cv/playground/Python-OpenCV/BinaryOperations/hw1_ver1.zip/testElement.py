
from element import *

ele = element(1,1,1,1)
print(ele)


#mat = cv.CreateMat(10, 10, 1)# set channel to 1 for grey
#cv.cvCreateData(mat);